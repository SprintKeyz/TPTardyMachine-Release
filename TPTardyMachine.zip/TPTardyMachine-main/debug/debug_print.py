# this file contains functions to print in color for warnings and errors

def print_error(skk): print("\033[91m {}\033[00m" .format(skk))
 
def print_success(skk): print("\033[92m {}\033[00m" .format(skk))

def print_warning(skk): print("\033[93m {}\033[00m" .format(skk))
 
def print_info(skk): print("\033[96m {}\033[00m" .format(skk))

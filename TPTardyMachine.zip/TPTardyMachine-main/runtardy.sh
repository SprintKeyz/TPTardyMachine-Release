#!/bin/sh
python /home/davis/tardy/main.py
import sys
import argparse
import socket

from gauth.drive_manager import DriveManager
from display.display_manager import Display, Font, ImageOptions
from debug.debug_print import print_error, print_warning, print_success, print_info

# get args
parser = argparse.ArgumentParser(description='Tardy Machine')
parser.add_argument('--offline', action='store_true', help='Run in offline mode')
parser.add_argument('--manual-login', action='store_true', help='Disable Drive Autologin to generate new token')

args = parser.parse_args()

version = sys.version_info
version_str = f"{version.major}.{version.minor}.{version.micro}"    # version of the python interpreter
built_version_str = "3.11.3"                                        # version of the python interpreter the program was built on
this_ip = socket.gethostbyname(socket.gethostname() + ".local")     # IP address of the device

display = Display(default_font=Font.FONT17)

display.write_image('hexapin.bmp', options=ImageOptions(keep_aspect_ratio=True, width=48), x=display.get_width() - 48 - 8, y=8)
start_string = "Starting Tardy3"
if args.offline:
    start_string += " (Offline)"

if args.manual_login:
    start_string += " (Manual Login)"

display.write_line(start_string + "...")
display.show_partial()

print(f'Running on Python {version_str}...')

# warn the user in case they encounter issues due to incompatible python versions
if version_str != built_version_str:
    print()
    print_warning(f"Warning: This program was built on Python {built_version_str}, but you are running Python {version_str}.")
    print_warning(f"If you run into issues, please try running on {built_version_str}!")

    display.write_line()
    display.write_line("  [WARN] Python version mismatch!")
    display.write_line("  [WARN] Built on 3.12.3, running on " + version_str + ".")
    display.write_line("  [WARN] If you have issues, try running on 3.12.3")
    display.show_partial()

print()

if this_ip == "127.0.0.1" or args.offline:
    print_error("Error: This device is runing offline!")
    print_error("Unable to reach Google APIs and update students directory.")

    display.write_line()
    display.write_line("  [ERR] Device not connected to network!")
    display.write_line("  [ERR] Exiting...")
    display.show_partial()

    exit(1)

else:
    print(f"This IP: {this_ip}")

    display.write_line()
    display.write_line("  [INFO] Device IP: " + this_ip)
    display.show_partial()

    print()

    print_info("Connecting to Google Cloud...")
    display.write_line()
    display.write_line("  [INFO] Connecting to Google Cloud...")
    display.show_partial()
    
    # connect
    google_drive_manager = DriveManager(display, args.manual_login)

    print_success("Connected to Google Cloud!")
    display.write_line("  [SUCCESS] Connected to Google Cloud!")
    display.show_partial()

    # clear screen
    display.clear()

    # display main menu
    display.write_image('hexapin.bmp', options=ImageOptions(keep_aspect_ratio=True, width=64), x=display.get_width() - 64 - 8, y=8)
    display.write_line("Sign In", Font.FONT36)
    display.write_line("Please type your ID:", Font.FONT24)
    display.show_partial()

    import time
    while True:
        time.sleep(1)
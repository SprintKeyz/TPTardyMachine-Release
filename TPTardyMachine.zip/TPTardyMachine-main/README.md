Instructions to set up selenium:

1) remove chromium latest:
sudo apt-get remove chromium-browser

2) Install chromium 98:
- wget -qO- https://raw.githubusercontent.com/Botspot/pi-apps/master/install | bash
- run pi-apps
- select browser
- select "downgrade chromium"
- select "install chromium 98"
- verify chromium version with `chromium-browser --version` (should be 98.0.4758.106)

3) Install undetected chromedriver for armv7:
- pip uninstall undetected-chromedriver --break-system-packages
- make a directory in home called "chromedriver"
- wget https://github.com/SprintKeyz/undetected-chromedriver-rpi/archive/refs/heads/master.zip
- unzip v.1.0.zip
- cd undetected-chromedriver-1.0
- run pip3 install . --break-system-packages
- clean up and remove the zip and directory

4) Install selenium 4.1.0:
- pip uninstall selenium --break-system-packages
- pip install selenium==4.1.0 --break-system-packages
- test with `python -c "import selenium; print(selenium.__version__)"` (should be 4.1.0)

5) Using the undetected chromedriver:
- install pyvirtualdisplay with `pip install pyvirtualdisplay --break-system-packages`

```python
import undetected_chromedriver as uc
from pyvirtualdisplay import Display

display = Display(visible=0, size=(800, 600))
display.start()

options = uc.ChromeOptions()

# very important flags:
options.add_argument("enable-automation")
options.add_argument("--no-sandbox")
options.add_argument("--disable-extensions")
options.add_argument("--dns-prefetch-disable")
options.add_argument("--disable-gpu")

driver = uc.Chrome(options=options, version_main=98, enable_cdp_events=True)

# use as normal
```

-----------------------

Autorun at startup instructions:

sudo nano /lib/systemd/system/tardymachine.service

add the following:

```
[Unit]
Description=Tardy Machine
Wants=graphical.target network-online.target
After=graphical.target network-online.target
StartLimitIntervalSec=10

[Service]
WorkingDirectory=/home/<your username>/tardy
User=<your username>
Environemnt=DISPLAY=:0
Environment=XAUTHORITY=/home/<your username>/.Xauthority
ExecStart=/bin/bash -c 'sh /home/<your username>/tardy/runtardy.sh > /home/<your username>/tardy/tardyservice.log 2>&1'
StartLimitBurst=3
KillMode=process
TimeoutSec=infinity

[Install]
WantedBy=graphical.target
```
then: 

sudo systemctl daemon-reload
sudo systemctl enable tardymachine.service

and finally to test, sudo reboot
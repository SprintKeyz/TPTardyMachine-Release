# https://nicolaslouge.com/post/how-to-set-up-selenium-python-geckodriver-raspberry-pi-arm-2023/
# use above buide but use v0.34.0 for geckodriver and firefox-esr
# also sudo apt-get install xvfb

from debug.debug_print import print_error, print_warning, print_success, print_info
from display.display_manager import Display as DM
from display.display_manager import Font

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

import undetected_chromedriver as uc
from pyvirtualdisplay import Display
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import os
import sys
import time

cwd = '/home/davis/tardy/gauth'
token_path = cwd + '/token.json'
client_secrets_path = os.path.join(cwd, 'client_secrets.json')

# get username and password from login.txt
# format:
# username=<username>
# password=<password>
# is_secure=<True/False>

def get_login_info(display: DM):
	try:
		with open(os.path.join(cwd, 'login.txt')) as f:
			lines = f.readlines()

			username = lines[0].strip().split('=')[1]
			password = lines[1].strip().split('=')[1]

			return username, password
		
	except Exception as e:
		print_error(f"Error reading login info: {e}")
		display.write_line("  [ERROR] Error reading login info!")
		display.write_line("  [ERROR] Ensure your credentials are correct.")
		display.show_partial()
		exit(1)

class DriveManager:
	def __init__(self, displaymanager: DM, manual_login: bool = False):
		SCOPES = ['https://www.googleapis.com/auth/drive']

		print_info("Initializing DriveManager...")

		creds = None
		global has_retried

		if os.path.exists(token_path):
			# read the token file to a string
			token_str = None
			with open(token_path, 'r') as token:
				token_str = token.read()

			# check if the token file is empty
			if len(token_str) < 10:
				print_info("Token file is empty, deleting...")
				os.remove(token_path)

			else:
				token.close()
				print_info("Token found, loading...")
				creds = Credentials.from_authorized_user_file(token_path, SCOPES)

		if not creds or not creds.valid:
			print_info("No valid token found, generating...")
			if creds and creds.expired and creds.refresh_token:
				creds.refresh(Request())
				displaymanager.write_line("  [INFO] Token expired, refreshing...")
				displaymanager.show_partial()

			else:
				if not manual_login:
					flow = InstalledAppFlow.from_client_secrets_file(client_secrets_path, scopes=SCOPES, redirect_uri='urn:ietf:wg:oauth:2.0:oob')
					auth_uri = flow.authorization_url()

					print_info("Got auth URI")

					try:
						username, password = get_login_info(displaymanager)

						print_info("Loaded login info")

						# vdisplay
						display = Display(visible=0, size=(800, 600))
						display.start()

						print_info("Display started")

						options = uc.ChromeOptions()
						options.add_argument('enable-automation')
						options.add_argument('--no-sandbox')
						options.add_argument('--disable-extensions')
						options.add_argument('--dns-prefetch-disable')
						options.add_argument('--disable-gpu')

						# Path to the chromedriver
						driver = uc.Chrome(options=options, version_main=98, enable_cdp_events=True)

						print_info('Starting autologin...')
						displaymanager.write_line("  [INFO] No token found, attempting to generate...")
						displaymanager.show_partial()

						driver.get(auth_uri[0])

						driver.implicitly_wait(10)

						print_info('Username: ' + username)
						print_info('Password: ' + password)
     
						email_input = driver.find_element(By.ID, "identifierId")
						email_input.send_keys(username)

						driver.find_element(By.ID, "identifierNext").click()

						print_info('Entering password...')
     
						# enter password
						wait = WebDriverWait(driver, 10)

						password_input = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[@name='Passwd']")))
						password_input.send_keys(password)

						driver.find_element(By.ID, "passwordNext").click()

						print_info('Logged in')
						displaymanager.write_line("  [INFO] Signed in to Google")
						displaymanager.show_partial()

						# wait for span with text "Continue" to appear
						continue_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Continue']")))
						continue_button.click()

						# wait for the element to DISAPPEAR
						time.sleep(5)

						# wait again for the same continue button to appear
						continue_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//span[text()='Continue']")))
						continue_button.click()

						code_element = wait.until(EC.visibility_of_element_located((By.XPATH, "//textarea[@readonly and @translate='no']")))
						code = code_element.get_attribute("value")

						print_info(f"Code: {code}")
						displaymanager.write_line("  [INFO] Got code, generating token...")

						driver.quit()
						display.stop()

						flow.fetch_token(code=code)
						creds = flow.credentials

					except Exception as e:
						print_error("Error generating token.")
						print(e)
						displaymanager.set_fast_refresh(False)
						displaymanager.clear()

						displaymanager.write_line("Couldn't get token!", font=Font.FONT36)
						displaymanager.write_line("Please check documentation if this persists.", font=Font.FONT24)
						displaymanager.show()

						time.sleep(6)
						exit(1)
      
				else:
					flow = InstalledAppFlow.from_client_secrets_file(client_secrets_path, scopes=SCOPES, redirect_uri='urn:ietf:wg:oauth:2.0:oob')
					auth_uri = flow.authorization_url()
     
					print_info("Got auth URI")
					print_info("Please visit the following URL and paste the code here:")
					print_info(auth_uri[0])
					
					displaymanager.write_line("  [INFO] Waiting for code...")
					displaymanager.show_partial()
	
					code = input("Enter the code: ")
					flow.fetch_token(code=code)
					creds = flow.credentials

				with open(token_path, 'w') as token:
					token.write(creds.to_json())

		try:
			self.service = build('drive', 'v3', credentials=creds)

		except HttpError as e:
			print_error(f"Error connecting to Google Cloud: {e}")
			displaymanager.write_line("  [ERROR] Error connecting to Google Cloud!")
			displaymanager.show_partial()
			exit(1)
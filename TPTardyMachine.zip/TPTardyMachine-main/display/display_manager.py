import sys
import os
import display.epd4in2_V2 as epd4in2_V2
import time
import traceback

from PIL import Image, ImageDraw, ImageFont

cwd = '/home/davis/tardy'
res_dir = os.path.join(cwd, 'resources')

class Font():
	FONT48 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 48)
	FONT36 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 36)
	FONT24 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 24)
	FONT20 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 20)
	FONT18 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 18)
	FONT17 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 17)
	FONT16 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 16)
	FONT14 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 14)
	FONT12 = ImageFont.truetype(os.path.join(res_dir, 'Font.ttc'), 12)

class ImageOptions():
	def __init__(self, width=None, height=None, bw=True, keep_aspect_ratio=True):
		self.width = width
		self.height = height
		self.bw = bw
		self.keep_aspect_ratio = keep_aspect_ratio

class Display():
	def __init__(self, vertical=False, default_font=Font.FONT16):
		print('Initializing display...')
		self.epd = epd4in2_V2.EPD()

		# clear
		self.epd.init()
		self.epd.Clear()

		# default font
		self.default_font = default_font

		# last line y position
		self.last_line_y = 0

		# fast refresh
		self.is_fast_refresh = False

		# vertical
		if vertical:
			self.is_vertical = True
			self.Image = Image.new('1', (self.epd.height, self.epd.width), 255)

		else:
			self.is_vertical = False
			self.Image = Image.new('1', (self.epd.width, self.epd.height), 255)

	def get_dimensions(self):
		return self.epd.width, self.epd.height
	
	def write_text(self, text, font=None, x=0, y=0):
		if font is None:
			font = self.default_font

		# create image
		draw = ImageDraw.Draw(self.Image)

		# draw text
		draw.text((x, y), text, font=font, fill=0)

	def write_text_center(self, text, font=None, y=0):
		if font is None:
			font = self.default_font

		# create image
		draw = ImageDraw.Draw(self.Image)

		# get text size
		text_size = draw.textsize(text, font=font)

		# calculate x
		x = int((self.epd.width - text_size[0]) / 2)

		# draw text
		draw.text((x, y), text, font=font, fill=0)

	def write_line(self, text="", font=None, x_offset=0, y_offset=5):
		if font is None:
			font = self.default_font

		# create image
		draw = ImageDraw.Draw(self.Image)

		# get text height
		text_size = font.size

		# calculate x
		x = x_offset

		# calculate y
		y = self.last_line_y + y_offset

		# draw text
		draw.text((x, y), text, font=font, fill=0)

		# update last line y
		self.last_line_y = y + text_size

	def write_image(self, image_path, x=0, y=0, options=ImageOptions()):
		# open image
		Timage = Image.open(os.path.join(res_dir, image_path))
		Timage_size = Timage.size

		new_width = None
		new_height = None

		if options.width is not None:
			if options.keep_aspect_ratio:
				new_width = options.width
				new_height = int(Timage_size[1] * (new_width / Timage_size[0]))

			else:
				new_width = options.width

		if options.height is not None:
			if options.keep_aspect_ratio:
				new_height = options.height
				new_width = int(Timage_size[0] * (new_height / Timage_size[1]))

			else:
				new_height = options.height

		if new_width is not None and new_height is not None:
			Timage = Timage.resize((new_width, new_height))

		if options.bw:
			Timage = Timage.convert('1')

		self.Image.paste(Timage, (x, y))

	def show(self):
		if self.is_fast_refresh:
			self.epd.init()
			self.is_fast_refresh = False

		self.epd.display(self.epd.getbuffer(self.Image))

	def show_partial(self):
		if not self.is_fast_refresh:
			self.epd.init_fast(self.epd.Seconds_1_5S)
			self.is_fast_refresh = True

		self.epd.display_Partial(self.epd.getbuffer(self.Image))

	def set_fast_refresh(self, is_fast_refresh):
		self.is_fast_refresh = is_fast_refresh

		if is_fast_refresh:
			self.epd.init_fast(self.epd.Seconds_1_5S)

		else:
			self.epd.init()

	def is_fast_refresh(self):
		return self.is_fast_refresh

	def clear(self):
		self.set_fast_refresh(False)

		if self.is_vertical:
			self.Image = Image.new('1', (self.epd.height, self.epd.width), 255)

		else:
			self.Image = Image.new('1', (self.epd.width, self.epd.height), 255)

		self.epd.Clear()

		self.last_line_y = 0

	def clear_parial(self, x=0, y=0, width=None, height=None):
		if width is None:
			width = self.epd.width

		if height is None:
			height = self.epd.height

		draw = ImageDraw.Draw(self.Image)
		draw.rectangle((x, y, x + width, y + height), fill=255)
		self.show_partial()

		self.last_line_y = 0

	def get_vertical(self):
		return self.is_vertical
	
	def get_width(self):
		return self.epd.width
	
	def get_height(self):
		return self.epd.height
	
		